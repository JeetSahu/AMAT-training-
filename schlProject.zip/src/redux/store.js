import {configureStore} from "@reduxjs/toolkit";
import {budgetsReducer} from "./budgetReducer";
import {expensesReducer} from "./expenseReducer";
import {totalBudgetsReducer} from "./totalBudgetReducer";

const store = configureStore({
  reducer: {
    budgets: budgetsReducer,
    expenses: expensesReducer,
    totalBudget: totalBudgetsReducer
  }
});

export default store;
