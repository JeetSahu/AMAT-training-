// const person = {
//     name: 'Harsha',
//     age: 32,
//     // greet: function() {
//     //     console.log(`Hi! this is ${this.name}`);
//     // },
//     greet(){
//         console.log(`Hi! this is ${this.name}`);
//     }
//     // greet: () => {
//     //     console.log(`Hi! this is ${this.name}`);
//     // }
// }

// const person1 = {
//     ...person,
//     name: 'Vardhan',
// }

// function greetingFunction() {
//     // person.greet();
//     let { greet } = person;

//     // greet = greet.bind(person);

//     // greet();

//     // greet.call(person);

//     greet.apply(person1)
// }

// greetingFunction();

// const person = {
//     name: 'Harsha',
//     age: 32,
//     greet(){
//         console.log(`Hi! this is ${this.name}`);
//     }
// };

// const person2 = {...person, name: 'Vardhan', sex: 'Male'};



