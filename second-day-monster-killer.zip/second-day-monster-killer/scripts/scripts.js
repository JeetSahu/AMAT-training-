const DEFAULT_LIFE = 100;
const MONSTER_POWER = 14;
const PLAYER_POWER = 10;
const PLAYER_STRONG_POWER = 15;
const HEAL_PLAYER_STRENGTH = 10;

const STRONG_ATTACK = 'STRONG_ATTACK';
const ATTACK = 'ATTACK';

let player_life = DEFAULT_LIFE;
let monster_life = DEFAULT_LIFE;

const event_logs = [];

// UPDATING PROGRESS BAR WITH DEFAULT VALUES
updateDefaultProgressBarValues(DEFAULT_LIFE);

function resetGame() {
    setTimeout(() => {
        playerElement.appendChild(playerLifeElement);
        updateDefaultProgressBarValues(DEFAULT_LIFE);
    }, 3000);
}

function assessResult(mode) {
    const powerOfPlayer = mode === STRONG_ATTACK ? PLAYER_STRONG_POWER : PLAYER_POWER;
    let isGameOver = false;
    let playerLifeBeforeAction = player_life;
    let monsterLifeBeforeAction = monster_life;

    player_life = attackByMonster(MONSTER_POWER);
    monster_life = attackByPlayer(powerOfPlayer);

    eventsRegistration(
        mode,
        playerLifeBeforeAction,
        monsterLifeBeforeAction,
    );

    if (player_life <= 0 && monster_life > 0) {
        if (playerLifeElement.parentNode) {
            playerLifeBeforeAction = player_life;
            monsterLifeBeforeAction = monster_life;
            healBtnHandler();
            eventsRegistration(
                'UTILISING_LIFE',
                playerLifeBeforeAction,
                monsterLifeBeforeAction,
            );
            // playerLifeElement.parentNode.removeChild(playerLifeElement);
            playerLifeElement.remove();
            alert("You lost and saved by your life!")
        } else {
            eventsRegistration(
                'PLAYER LOST',
                playerLifeBeforeAction,
                monsterLifeBeforeAction,
            );
            alert('You Lost');
            isGameOver = true;
        }
    } else if (monster_life <= 0 && player_life > 0) {
        isGameOver = true;
        eventsRegistration(
            'PLAYER WON',
            playerLifeBeforeAction,
            monsterLifeBeforeAction,
        );
        alert('You Win');
    } else if (player_life <= 0 && monster_life <=0) {
        isGameOver = true;
        eventsRegistration(
            'ITS DRAW',
            playerLifeBeforeAction,
            monsterLifeBeforeAction,
        );
        alert('Its a Draw!');
    }

    if (isGameOver) {
        resetGame();
    }
}

function attackHandler() {
    assessResult(ATTACK);
};

function strongAttackHandler() {
    assessResult(STRONG_ATTACK);
};

function eventsRegistration(
    event,
    playerLifeBeforeAction,
    monsterLifeBeforeAction
) {
    event_logs.push({
        event,
        playerPreviousHealth: playerLifeBeforeAction,
        monsterPreviousHealth: monsterLifeBeforeAction,
        player_life,
        monster_life,
        timeStamp: new Date(),
    });
}

function healBtnHandler () {
    let playerLifeBeforeAction = player_life;
    let monsterLifeBeforeAction = monster_life;
    if (player_life < 80) {
        eventsRegistration(
            'HEALING',
            playerLifeBeforeAction,
            monsterLifeBeforeAction,
        )
        player_life = healPlayer(HEAL_PLAYER_STRENGTH);
    }
}

function showLogsHandler() {
    if (logContainer.style.display === '' || logContainer.style.display === 'none') {
        logContainer.style.display = 'block';
        event_logs.map((log) => {
            const spanElement = document.createElement('div');
            spanElement.innerText = log.event;
            logContainer.appendChild(spanElement);
        });
        logBtn.innerHTML = "Hide Logs";
    } else {
        logBtn.innerHTML = "Show Log";
        logContainer.style.display = 'none';
        logContainer.innerHTML = "";
    }
}

attackBtn.addEventListener('click', attackHandler);
strongAttackBtn.addEventListener('click', strongAttackHandler);
healBtn.addEventListener('click', healBtnHandler);
logBtn.addEventListener('click', showLogsHandler);
