import React, {useState} from "react";
import {useDispatch, useSelector} from "react-redux";
import {addBudget} from "../redux/budgetReducer";
import {addExpense} from "../redux/expenseReducer";

const Expense = () => {
  const [year, setYear] = useState("2023");
  const [date, setDate] = useState();
  const [expenseName, setExpenseName] = useState();
  const [expenseAmount, setExpenseAmount] = useState();
  const dispatch = useDispatch();
  const budgetData = useSelector((state) => state.expenses);

  const handelBudgetSubmit = () => {
    dispatch(
      addExpense({
        ["name"]: expenseName,
        ["amount"]: expenseAmount,
        ["date"]: date
      })
    );
    setExpenseName("");
    setExpenseAmount("");
    setDate();
  };

  return (
    <div className="">
      <div className="flex space-x-6">
        <label className="p-4 lg:p-7 bg-green-50  space-x-6">
          Expense Name
        </label>
        <input
          type="text"
          className="rounded-md border p-2 text-gray-700 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
          value={expenseName}
          onChange={(e) => setExpenseName(e.target.value)}
        />
      </div>
      <div className="flex space-x-6">
        <label className="p-4 lg:p-7 bg-green-50  space-x-6">Expense</label>
        <input
          type="number"
          className="rounded-md border p-2 text-gray-700 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
          value={expenseAmount}
          onChange={(e) => setExpenseAmount(e.target.value)}
        />
      </div>
      <div className="flex space-x-6">
        <label className="p-4 lg:p-7 bg-green-50 bold-900 space-x-6">
          Date
        </label>
        <input
          type="date"
          className="rounded-md border p-2 text-gray-700 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
          value={date}
          onChange={(e) => setDate(e.target.value)}
        />
      </div>
      <button
        className={`flexCenter gap-3 rounded-full border mt-5 bg-black-100 w-[200px] bg-blue-500 py-2 px-4`}
        type={"submit"}
        onClick={handelBudgetSubmit}
      >
        <label className="bold-16 whitespace-nowrap cursor-pointer text-white-700">
          Submit Expense
        </label>
      </button>
      <div>Expenses List</div>
      <table>
      <thead>
        <tr>
          <th>Name</th>
          <th>Amount</th>
          <th>Date</th>
          
        </tr>
      </thead>
      <tbody>
        {budgetData?.map(item => (
          <tr key={item.name}>
            <td>{item.name}</td>  
            <td>{item.amount}</td>
            <td>{item.date}</td>
          </tr>
        ))}
      </tbody>
    </table>
    </div>
  );
};

export default Expense;
