const app = document.getElementById('app');

class ProductItem {
    name = 'Default';
    price = '';
    img = '';
    description = '';

    constructor(name, price, img, description) {
        this.name = name;
        this.price = price;
        this.img = img;
        this.description = description;
    }
};

const productsList = {
    products: [
        new ProductItem(
            'Pillow', 
            500, 
            'https://m.media-amazon.com/images/I/71ymQlkXDQL._AC_UF894,1000_QL80_.jpg', 
            'Its a soft pillow'
        ),
        new ProductItem(
            'Carpet', 
            3500, 
            'https://t4.ftcdn.net/jpg/00/89/76/09/360_F_89760942_RmpjUzGtDcERW1rlkNaifMr58NCVu7YB.jpg', 
            'Its a good woolen carpet or not'
        ),
    ],
    render() {
        const ulEle = document.createElement('ul');
        ulEle.className = 'product-list'
        this.products.map(product => {
            const liEle = document.createElement('li');
            liEle.className = 'product-item';
            liEle.innerHTML = `
                <div>
                    <img class="product-image" src=${product.img} />
                    <div class="product-description-container">
                        <h2>${product.name}</h2>
                        <h3>COST: ${product.price} \$</h3>
                        <p>${product.description}</p>
                        <button class="product-class">Add</button>
                    </div>
                <div>
            `;
            ulEle.appendChild(liEle);
        });
        return ulEle;
    }
};

app.append(productsList.render());
