import React, {useEffect, useState} from "react";
import {useDispatch, useSelector} from "react-redux";
import {addBudget} from "../redux/budgetReducer";
import {addTotalBudget} from "../redux/totalBudgetReducer";

const Budget = () => {
  const [year, setYear] = useState("2023");
  const [month, setMonth] = useState("January");
  const [budget, setBudget] = useState(0);
  const [currentAmount, setCurrentAmount] = useState(0);
  const [isName, setIsName] = useState(false);
  const [budgetName, setBudgetName] = useState();
  const [budgetAmount, setBudgetAmount] = useState();
  const dispatch = useDispatch();
  const budgetData = useSelector((state) => state.budgets);
  const budgetTotalData = useSelector((state) => state.totalBudget);
  useEffect(() => {
    const total = budgetTotalData?.filter(
      (i) => i.year === year && i.month === month
    );
    if (total?.length > 0) {
      setBudget(total[0]?.totalAmount);
      setCurrentAmount(total[0]?.totalAmount);
      setIsName(true);
    } else {
      setBudget(0);
      setCurrentAmount(0);
      setIsName(false);
    }
  }, [budgetTotalData, year, month]);
  const handelBudgetSubmit = () => {
    console.log("handelBudget", budget);
    if (budget > 0) {
      dispatch(
        addTotalBudget({
          ["totalAmount"]: budget,
          ["year"]: year,
          ["month"]: month
        })
      );
    } else {
      alert("Please enter a budget greater than zero");
    }
  };
  const handelBudgetName = () => {
    let total = 0;
    budgetData?.forEach((t) => {
      if (t.year === year && t.month === month) {
        total += t.amount;
      }
    });

    if (
      Number(budgetAmount) < Number(currentAmount) &&
      budgetData?.length === 0
    ) {
      dispatch(
        addBudget({
          ["name"]: budgetName,
          ["amount"]: budgetAmount,
          ["year"]: year,
          ["month"]: month
        })
      );
    } else if (Number(total + budgetAmount) < Number(currentAmount)) {
      debugger;
      dispatch(
        addBudget({
          ["name"]: budgetName,
          ["amount"]: budgetAmount,
          ["year"]: year,
          ["month"]: month
        })
      );
    } else {
      alert("Expense Cannot be Greater than Budget Amount");
    }
  };
  const years = [
    "2023",
    "2024",
    "2025",
    "2026",
    "2027",
    "2028",
    "2029",
    "2030"
  ];

  const months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
  ];
  return (
    <div className="">
      <div className="flex space-x-6">
        <label className="p-4 lg:p-7 bg-green-50  space-x-6">
          Please Select budget Year and Month
        </label>
        <select
          className="rounded-md border p-2 text-gray-700 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
          value={year}
          onChange={(e) => setYear(e.target.value)}
        >
          {years.map((y) => (
            <option key={y}>{y}</option>
          ))}
        </select>

        <select
          className="rounded-md border p-2 text-gray-700 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
          value={month}
          onChange={(e) => setMonth(e.target.value)}
        >
          {months.map((m) => (
            <option key={m}>{m}</option>
          ))}
        </select>
      </div>
      <div className="flex space-x-6">
        <label className="p-4 lg:p-7 bg-green-50 bold-900 space-x-6">
          Please Enter your budget
        </label>
        <input
          type="number"
          className="rounded-md border p-2 text-gray-700 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
          value={budget}
          onChange={(e) => setBudget(e.target.value)}
        />
      </div>
      <button
        className={`flexCenter gap-3 rounded-full border mt-5 bg-black-100 w-[200px] bg-blue-500 py-2 px-4`}
        type={"submit"}
        onClick={handelBudgetSubmit}
      >
        <label className="bold-16 whitespace-nowrap cursor-pointer text-white-700">
          Submit your Budget
        </label>
      </button>
      {isName && (
        <>
          <div className="flex space-x-6">
            <label className="p-4 lg:p-7 bg-green-50 bold-900 space-x-6">
              Budget Name
            </label>
            <input
              type="text"
              className="rounded-md border p-2 text-gray-700 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              value={budgetName}
              onChange={(e) => setBudgetName(e.target.value)}
            />
          </div>
          <div className="flex space-x-6">
            <label className="p-4 lg:p-7 bg-green-50 bold-900 space-x-6">
              Budget
            </label>
            <input
              type="number"
              className="rounded-md border p-2 text-gray-700 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              value={budgetAmount}
              onChange={(e) => setBudgetAmount(e.target.value)}
            />
          </div>
          <button
            className={`flexCenter gap-3 rounded-full border mt-5 bg-black-100 w-[200px] bg-blue-500 py-2 px-4`}
            type={"submit"}
            onClick={handelBudgetName}
          >
            <label className="bold-16 whitespace-nowrap cursor-pointer text-white-700">
              Submit Expense
            </label>
          </button>
        </>
      )}
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Amount</th>
          </tr>
        </thead>
        <tbody>
          {budgetData?.map((item) => (
            <tr key={item.name}>
              <td>{item.name}</td>
              <td>{item.amount}</td>
            </tr>
          ))}
        </tbody>
      </table>

      {budgetData?.map((item, index) => {
        return (
          <>
            <div>Budget Details</div>
            <div key={index} className="bg-gray-100 p-4 rounded-lg shadow-md">
              <p className="text-gray-700">
                <h3 className="text-lg font-bold mb-2">Name: {item?.name}</h3>
              </p>
              <p className="text-gray-700">
                <span className="font-semibold">Amount:</span> {item?.amount}
              </p>
            </div>
          </>
        );
      })}
    </div>
  );
};

export default Budget;
