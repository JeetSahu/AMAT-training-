import { createSlice } from '@reduxjs/toolkit';

const budgetsSlice = createSlice({
  name: 'budgets',
  initialState: [
  ],
  reducers: {
    addBudget: (state, action) => {
      state.push(action.payload);
    }
  }
});

export const { addBudget } = budgetsSlice.actions;
export const budgetsReducer = budgetsSlice.reducer;

// slices/expensesSlice.js


