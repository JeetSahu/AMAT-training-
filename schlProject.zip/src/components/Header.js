import React from 'react'
import { Link } from 'react-router-dom'

const Header = () => {
  return (
   
    <nav className="w-full flexBetween  relative z-30 py-5 bg-gradient-to-r from-purple-500 to-indigo-600">
    <Link   to="/">Budget Planner </Link>  
    <ul className="hidden h-full gap-12 lg:flex">
      <Link   to="/">Home </Link>  
      <Link to="/budget">Budget</Link>
      <Link to="/expense">Expense</Link>
      </ul>
    </nav>
 
  )
}

export default Header