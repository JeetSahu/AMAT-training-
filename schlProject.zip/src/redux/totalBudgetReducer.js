import { createSlice } from '@reduxjs/toolkit';

const totalBudgetSlice = createSlice({
  name: 'totalBudget',
  initialState: [
  ],
  reducers: {
    addTotalBudget: (state, action) => {   
        state.push(action.payload);
          
    }
  }
});

export const { addTotalBudget } = totalBudgetSlice.actions;
export const totalBudgetsReducer = totalBudgetSlice.reducer;