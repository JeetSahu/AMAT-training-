const monsterProgressBar = document.getElementById('monster-progress-bar');
const playerProgressBar = document.getElementById('player-progress-bar');
const playerElement = document.getElementById('player');
const playerLifeElement = document.getElementById('player-life');

const attackBtn = document.getElementById('attack-btn');
const strongAttackBtn = document.getElementById('strong-attack-btn');
const healBtn = document.getElementById('heal-btn');
const logBtn = document.getElementById('log-btn');

const logContainer = document.getElementById("log-container");

function updateDefaultProgressBarValues(value) {
    monsterProgressBar.value = value;
    playerProgressBar.value = value;
}

// player life has to decrease because of monster attack
function attackByMonster(power) {
    const lifeLost = Math.random() * power;
    playerProgressBar.value = +playerProgressBar.value - lifeLost;
    return playerProgressBar.value;
}

// monster life has to decrease because of player attack
function attackByPlayer(power) {
    const lifeLost = Math.random() * power;
    monsterProgressBar.value = +monsterProgressBar.value - lifeLost;
    return monsterProgressBar.value;
}

function healPlayer(value) {
    playerProgressBar.value = +playerProgressBar.value + value;
    return playerProgressBar.value;
}
