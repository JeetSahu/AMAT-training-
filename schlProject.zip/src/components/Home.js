import React from "react";
import PieChart from "./PieChart";
import BarChart from "./BarChart";
import {useSelector} from "react-redux";

const Home = () => {
  const budgetData = useSelector((state) => state.budgets);
  const budgetTotalData = useSelector((state) => state.totalBudget);
  const expenseData = useSelector((state) => state.expenses);
  return (
    <div className={"h-full w-full min-w-[1100px] "}>
      <div>HI User</div>
      <div className="flex flex-row">
        <div className="flex h-[300px] flex-col items-start justify-between p-6 lg:px-20 lg:py-10">
          <PieChart />
        </div>
        <div className="flex h-[300px] flex-col items-start justify-between p-6 lg:px-20 lg:py-10">
          {/* // passing the props  */}
          <PieChart
            budgetData={budgetData}
            budgetTotalData={budgetTotalData}
            expenseData={expenseData}
          />
        </div>
      </div>

      <div className="flex h-[300px] w-[1500px] flex-col items-start justify-between p-6 lg:px-20 lg:py-10">
        {/* // passing the props  budgetData  */}
        <BarChart
          budgetData={budgetData}
          budgetTotalData={budgetTotalData}
          expenseData={expenseData}
        />
      </div>
    </div>
  );
};

export default Home;
